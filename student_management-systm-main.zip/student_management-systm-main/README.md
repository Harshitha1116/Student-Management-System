# student_management-systm
A simple web application built with Django that performs CRUD operations (Create, Read, Update, Delete) to manage student records including name, age, email, and course.
